from restaurant_9_1 import Restaurant

restaurant_1 = Restaurant("KFC", "Fried chicken and burgers")
restaurant_2 = Restaurant("McDonald's", "Fried chicken and burgers")
restaurant_3 = Restaurant("Quanjude", "Peking duck")


restaurant_1.describe_restaurant()
print()

restaurant_2.describe_restaurant()
print()

restaurant_3.describe_restaurant()
print()